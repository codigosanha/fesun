#
# TABLE STRUCTURE FOR: actividad_laboral
#

DROP TABLE IF EXISTS `actividad_laboral`;

CREATE TABLE `actividad_laboral` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `actividad` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `actividad_laboral` (`id`, `actividad`) VALUES ('1', 'Independiente');
INSERT INTO `actividad_laboral` (`id`, `actividad`) VALUES ('2', 'Asalariado');
INSERT INTO `actividad_laboral` (`id`, `actividad`) VALUES ('3', 'Hogar');
INSERT INTO `actividad_laboral` (`id`, `actividad`) VALUES ('4', 'Pensionado');


#
# TABLE STRUCTURE FOR: ahorros
#

DROP TABLE IF EXISTS `ahorros`;

CREATE TABLE `ahorros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `ahorros` (`id`, `nombre`) VALUES ('1', 'Permanente');
INSERT INTO `ahorros` (`id`, `nombre`) VALUES ('2', 'Voluntario');
INSERT INTO `ahorros` (`id`, `nombre`) VALUES ('3', 'Vivienda');
INSERT INTO `ahorros` (`id`, `nombre`) VALUES ('4', 'Navideño');
INSERT INTO `ahorros` (`id`, `nombre`) VALUES ('5', 'Vacaciones');
INSERT INTO `ahorros` (`id`, `nombre`) VALUES ('6', 'Educativo');


#
# TABLE STRUCTURE FOR: archivos
#

DROP TABLE IF EXISTS `archivos`;

CREATE TABLE `archivos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(100) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  `size` varchar(100) DEFAULT NULL,
  `extension` varchar(20) DEFAULT NULL,
  `tipo` tinyint(1) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `usuario_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  `finca_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('1', '5c3cd76f4907b', 'a', '', NULL, NULL, NULL, '2019-01-14 19:39:43', '0', '6', '0', '25');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('2', '5c3cd7cb75229', 'b', '', NULL, NULL, NULL, '2019-01-14 19:41:15', '0', '6', '0', '25');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('3', '5c3cdf161beb5', '176910', 'HERRERA  MARDOQUEO\r\n', NULL, NULL, NULL, '2019-01-14 20:12:22', '0', '1', '1', '3');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('4', '5c3cdf3c29153', '191769', 'ESPEJO  JOSE LEONIDAS\r\n', NULL, NULL, NULL, '2019-01-14 20:13:00', '0', '1', '1', '5');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('5', '5c3cdf617bdb4', '192340', 'CELIS MORENO MARCELINO\r\n', NULL, NULL, NULL, '2019-01-14 20:13:37', '0', '1', '1', '4');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('6', '5c3cdf70c096f', '193218', 'AMAYA MORENO JAVIER\r\n', NULL, NULL, NULL, '2019-01-14 20:13:52', '0', '1', '1', '5');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('7', '5c3cdf85beb36', '311834', 'MANJARRES SEGURA JOSE HELI\r\n', NULL, NULL, NULL, '2019-01-14 20:14:13', '0', '1', '1', '6');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('8', '5c3cdfbbcbe78', '316826', 'CARDENAS MALAVER JOSE ERIBERTO\r\n', NULL, NULL, NULL, '2019-01-14 20:15:07', '0', '1', '1', '17');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('9', '5c3cdfd17c477', '346268', 'HERNANDEZ PARRA JOSE JOAQUIN\r\n', NULL, NULL, NULL, '2019-01-14 20:15:29', '0', '1', '1', '11');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('10', '5c3cdfdf64af0', '357688', '', NULL, NULL, NULL, '2019-01-14 20:15:43', '0', '1', '0', '3');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('11', '5c3ce01a39723', '357688', 'SALDAÑA NIETO LUIS HERNANDO\r\n', NULL, NULL, NULL, '2019-01-14 20:16:42', '0', '1', '1', '3');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('12', '5c3ce02593378', '362459', 'SOLER VIVAS JOSE VICENTE\r\n', NULL, NULL, NULL, '2019-01-14 20:16:53', '0', '1', '1', '6');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('13', '5c3ce032453e1', '405987', 'GERENA RONCANCIO SALOMON\r\n', NULL, NULL, NULL, '2019-01-14 20:17:06', '0', '1', '1', '17');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('14', '5c3ce0533b7d9', '458486', 'CORTES ARIZA RUBIO\r\n', NULL, NULL, NULL, '2019-01-14 20:17:39', '0', '1', '1', '21');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('15', '5c3ce1e29af97', '1061445', 'BUSTACARA GONZALEZ LUIS ANTONIO\r\n', NULL, NULL, NULL, '2019-01-14 20:24:18', '0', '1', '1', '3');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('16', '5c3ce1fc2c554', '1106640', 'ESLAVA BUSTAZARA TOBIAS\r\n', NULL, NULL, NULL, '2019-01-14 20:24:44', '0', '1', '1', '27');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('17', '5c3ce20c70b0e', '2954037', 'BARRIGA IBAÑEZ JORGE ELIECER\r\n', NULL, NULL, NULL, '2019-01-14 20:25:00', '0', '1', '1', '5');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('18', '5c3ce25b8bacc', '176910.pdf', 'EXTRACTO A 31-12-2018', '136.11', '.pdf', '1', '2019-01-14 20:26:19', '3', '1', '1', '3');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('19', '5c3ce368849fb', '2954307', 'RIAÑO  HECTOR HERNANDO\r\n', NULL, NULL, NULL, '2019-01-14 20:30:48', '0', '1', '1', '14');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('20', '5c3ce37de6ea5', '2955024', 'MARTINEZ ALARCON VICTOR MANUEL\r\n', NULL, NULL, NULL, '2019-01-14 20:31:09', '0', '1', '1', '6');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('21', '5c3ce38e78522', '2955144', 'RAMIREZ TORRES CESAR HERNAN\r\n', NULL, NULL, NULL, '2019-01-14 20:31:26', '0', '1', '1', '5');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('22', '5c3ce3a0a6f86', '2956116', 'HERRERA  ALBEIRO\r\n', NULL, NULL, NULL, '2019-01-14 20:31:44', '0', '1', '1', '6');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('23', '5c3ce3b22a01f', '2956634', 'GOMEZ SOLANO LUIS ANTONIO\r\n', NULL, NULL, NULL, '2019-01-14 20:32:02', '0', '1', '1', '15');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('24', '5c3ce3c78f82e', '2969744', 'BARRETO RIVERA JOSE VICENTE\r\n', NULL, NULL, NULL, '2019-01-14 20:32:23', '0', '1', '1', '6');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('25', '5c3ce3d941c80', '2976951', 'TIBAVIZCO RAMIREZ ERNESTO\r\n', NULL, NULL, NULL, '2019-01-14 20:32:41', '0', '1', '1', '14');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('26', '5c3ce3ec1e273', '2977013', 'MEDINA AYURE GONZALO\r\n', NULL, NULL, NULL, '2019-01-14 20:33:00', '0', '1', '1', '14');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('27', '5c3ce3fdb97b5', '2983533', 'PACHON  FILADELFO\r\n', NULL, NULL, NULL, '2019-01-14 20:33:17', '0', '1', '1', '15');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('28', '5c3ce40e72e0f', '2984090', 'CORTES CASTIBLANCO KICO ORLANDO\r\n', NULL, NULL, NULL, '2019-01-14 20:33:34', '0', '1', '1', '26');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('29', '5c3ce42637ddf', '2984151', 'PINILLA PINILLA RAUL\r\n', NULL, NULL, NULL, '2019-01-14 20:33:58', '0', '1', '1', '11');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('30', '5c3ce44f16342', '2984313', 'PINILLA LUIS FERNANDO\r\n', NULL, NULL, NULL, '2019-01-14 20:34:39', '0', '1', '1', '15');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('31', '5c3ce46143d9a', '2988582', 'SANCHEZ MORENO LUIS CARLOS\r\n', NULL, NULL, NULL, '2019-01-14 20:34:57', '0', '1', '1', '15');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('32', '5c3ce47db5869', '2988783', 'PINILLA PINILLA CARLOS RODRIGO\r\n', NULL, NULL, NULL, '2019-01-14 20:35:25', '0', '1', '1', '7');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('33', '5c3ce4989c2c3', '2988955', 'PINILLA PINILLA URIEL\r\n', NULL, NULL, NULL, '2019-01-14 20:35:52', '0', '1', '1', '20');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('34', '5c3ce4ad849bb', '2990595', 'MONTEALEGRE BEJARANO MIGUEL ANTONIO\r\n', NULL, NULL, NULL, '2019-01-14 20:36:13', '0', '1', '1', '11');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('35', '5c3ce4c9cb1e5', '2994742', 'ORTIZ MORENO JOSE JOAQUIN\r\n', NULL, NULL, NULL, '2019-01-14 20:36:41', '0', '1', '1', '3');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('36', '5c3ce4ddc57b2', '2995636', 'GAONA RODRIGUEZ JOSE ALBERTO\r\n', NULL, NULL, NULL, '2019-01-14 20:37:01', '0', '1', '1', '6');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('37', '5c3ce4ed9595c', '2995639', 'BOSIGA MORENO ULPIANO\r\n', NULL, NULL, NULL, '2019-01-14 20:37:17', '0', '1', '1', '16');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('38', '5c3ce504c1229', '3007002', 'CASTRO LOPEZ ILSAN ARNULFO\r\n', NULL, NULL, NULL, '2019-01-14 20:37:40', '0', '1', '1', '5');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('39', '5c3ce5199c4ed', '3023663', 'PEÑA  LUIS GREGORIO\r\n', NULL, NULL, NULL, '2019-01-14 20:38:01', '0', '1', '1', '2');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('40', '5c3ce532523c1', '3023940', 'MONTAÑO ESPINEL MIGUEL ANTONIO\r\n', NULL, NULL, NULL, '2019-01-14 20:38:26', '0', '1', '1', '14');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('41', '5c3ce543b3caf', '3026833', 'BEJARANO CALDERON JULIO CESAR\r\n', NULL, NULL, NULL, '2019-01-14 20:38:43', '0', '1', '1', '15');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('42', '5c3ce555e8407', '3028009', 'PIÑEROS URREGO BERNABE\r\n', NULL, NULL, NULL, '2019-01-14 20:39:01', '0', '1', '1', '4');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('43', '5c3ce56c3f29a', '3058389', 'RODRIGUEZ GARZON HECTOR JULIO\r\n', NULL, NULL, NULL, '2019-01-14 20:39:24', '0', '1', '1', '12');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('44', '5c3ce5816ffe7', '3059510', 'LOPEZ  JORGE ENRIQUE\r\n', NULL, NULL, NULL, '2019-01-14 20:39:45', '0', '1', '1', '6');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('45', '5c3ce596767bf', '3061466', 'RINCON QUEVEDO OMAR\r\n', NULL, NULL, NULL, '2019-01-14 20:40:06', '0', '1', '1', '5');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('46', '5c3ce5cbb8a04', '3070454', 'RODRIGUEZ VARGAS JAVIER ALONSO\r\n', NULL, NULL, NULL, '2019-01-14 20:40:59', '0', '1', '1', '12');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('47', '5c3ce5de56844', '3079135', 'GAITAN TELLEZ LUIS ALBERTO\r\n', NULL, NULL, NULL, '2019-01-14 20:41:18', '0', '1', '1', '8');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('48', '5c3ce5ee0f46d', '3080510', 'HERNANDEZ  RICARDO\r\n', NULL, NULL, NULL, '2019-01-14 20:41:34', '0', '1', '1', '12');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('49', '5c3ce5fdf12cb', '3082559', 'LEON ESCOBAR JUAN CARLOS\r\n', NULL, NULL, NULL, '2019-01-14 20:41:49', '0', '1', '1', '6');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('50', '5c3ce6121f2f1', '3085406', 'PERILLA MATEUS CAMPO ELIAS\r\n', NULL, NULL, NULL, '2019-01-14 20:42:10', '0', '1', '1', '9');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('51', '5c3ce622cc403', '3086503', 'BENAVIDES  LUIS DANIEL\r\n', NULL, NULL, NULL, '2019-01-14 20:42:26', '0', '1', '1', '7');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('52', '5c3ce64292e1c', '3089982', 'SANDOVAL ZAMORA ANGEL MARIA\r\n', NULL, NULL, NULL, '2019-01-14 20:42:58', '0', '1', '1', '17');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('53', '5c3ce65a697c9', '3090706', 'GOMEZ DUEÑAS LUIS ORLANDO\r\n', NULL, NULL, NULL, '2019-01-14 20:43:22', '0', '1', '1', '15');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('54', '5c3ce6755b2b4', '3091727', 'SALAMANCA SALAMANCA ISRAEL\r\n', NULL, NULL, NULL, '2019-01-14 20:43:49', '0', '1', '1', '6');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('55', '5c3ce689e9f83', '3093933', 'OVALLE RUBIANO PEDRO PABLO\r\n', NULL, NULL, NULL, '2019-01-14 20:44:09', '0', '1', '1', '5');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('56', '5c3ce6c73a929', '3100858', 'RODRIGUEZ PARRA LUIS ERNESTO\r\n', NULL, NULL, NULL, '2019-01-14 20:45:11', '0', '1', '1', '5');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('57', '5c3ce7bfd09f7', '3102358', 'VELASQUEZ GARZON ISRAEL\r\n', NULL, NULL, NULL, '2019-01-14 20:49:19', '0', '1', '1', '1');
INSERT INTO `archivos` (`id`, `codigo`, `nombre`, `descripcion`, `size`, `extension`, `tipo`, `fecha`, `parent`, `usuario_id`, `estado`, `finca_id`) VALUES ('58', '5c3ce7d70b942', '3103046', 'ESPITIA FANDIÑO FERNANDO\r\n', NULL, NULL, NULL, '2019-01-14 20:49:43', '0', '1', '1', '29');


#
# TABLE STRUCTURE FOR: asociados
#

DROP TABLE IF EXISTS `asociados`;

CREATE TABLE `asociados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_vinculacion` int(11) NOT NULL,
  `fec_diligencia` date NOT NULL,
  `oficina` varchar(100) NOT NULL,
  `fecha_afiliacion` date NOT NULL,
  `interes` varchar(200) NOT NULL,
  `lugar_entrevista` varchar(250) NOT NULL,
  `fecha_entrevista` date NOT NULL,
  `hora` varchar(100) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `observaciones` text NOT NULL,
  `persona_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '0',
  `user_aprueba` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `asociados` (`id`, `tipo_vinculacion`, `fec_diligencia`, `oficina`, `fecha_afiliacion`, `interes`, `lugar_entrevista`, `fecha_entrevista`, `hora`, `usuario_id`, `observaciones`, `persona_id`, `estado`, `user_aprueba`) VALUES ('6', '2', '0000-00-00', 'Secretaria', '0000-00-00', 'Asociarse', '1', '0000-00-00', '02:15 PM', '1', 'obserrvaciones de diligenciamiento', '6', '2', '1');
INSERT INTO `asociados` (`id`, `tipo_vinculacion`, `fec_diligencia`, `oficina`, `fecha_afiliacion`, `interes`, `lugar_entrevista`, `fecha_entrevista`, `hora`, `usuario_id`, `observaciones`, `persona_id`, `estado`, `user_aprueba`) VALUES ('7', '1', '0000-00-00', 'Secretaria', '0000-00-00', 'Asociarse', '1', '0000-00-00', '10:30 PM', '2', 'observaciones de diligencia', '7', '0', '0');
INSERT INTO `asociados` (`id`, `tipo_vinculacion`, `fec_diligencia`, `oficina`, `fecha_afiliacion`, `interes`, `lugar_entrevista`, `fecha_entrevista`, `hora`, `usuario_id`, `observaciones`, `persona_id`, `estado`, `user_aprueba`) VALUES ('8', '1', '2018-07-06', 'Secretaria', '2018-09-07', 'Asociarse', '1', '2018-09-26', '07:30 AM', '1', 'observaciones ', '8', '1', '1');


#
# TABLE STRUCTURE FOR: beneficiarios
#

DROP TABLE IF EXISTS `beneficiarios`;

CREATE TABLE `beneficiarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(250) NOT NULL,
  `fec_nacimiento` date NOT NULL,
  `num_identificacion` int(11) NOT NULL,
  `parentesco` varchar(100) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `persona_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

INSERT INTO `beneficiarios` (`id`, `nombres`, `fec_nacimiento`, `num_identificacion`, `parentesco`, `telefono`, `persona_id`) VALUES ('1', 'Luis galdoz ', '0000-00-00', '78786424', 'Padre', NULL, '4');
INSERT INTO `beneficiarios` (`id`, `nombres`, `fec_nacimiento`, `num_identificacion`, `parentesco`, `telefono`, `persona_id`) VALUES ('2', 'Maria Paredes', '1975-11-28', '56565', 'Madre', NULL, '5');
INSERT INTO `beneficiarios` (`id`, `nombres`, `fec_nacimiento`, `num_identificacion`, `parentesco`, `telefono`, `persona_id`) VALUES ('21', 'Yeny Mamani', '1949-08-18', '78786424', 'Madre', '98888112', '7');
INSERT INTO `beneficiarios` (`id`, `nombres`, `fec_nacimiento`, `num_identificacion`, `parentesco`, `telefono`, `persona_id`) VALUES ('22', 'Luis galdoz ', '1969-08-22', '78786422', 'Padre', '98888112', '7');
INSERT INTO `beneficiarios` (`id`, `nombres`, `fec_nacimiento`, `num_identificacion`, `parentesco`, `telefono`, `persona_id`) VALUES ('23', 'Yeny Mamani', '2018-08-02', '78786424', 'Madre', '98888112', '7');
INSERT INTO `beneficiarios` (`id`, `nombres`, `fec_nacimiento`, `num_identificacion`, `parentesco`, `telefono`, `persona_id`) VALUES ('24', 'Carlos Fuentes', '1949-08-18', '78786424', 'Madre', '2323232', '8');


#
# TABLE STRUCTURE FOR: compartidos
#

DROP TABLE IF EXISTS `compartidos`;

CREATE TABLE `compartidos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_shared` int(11) NOT NULL,
  `fecha_shared` datetime NOT NULL,
  `archivo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `compartidos` (`id`, `user_shared`, `fecha_shared`, `archivo_id`) VALUES ('1', '6', '2019-01-14 20:39:07', '3');
INSERT INTO `compartidos` (`id`, `user_shared`, `fecha_shared`, `archivo_id`) VALUES ('2', '6', '2019-01-14 20:40:31', '18');


#
# TABLE STRUCTURE FOR: conyuges
#

DROP TABLE IF EXISTS `conyuges`;

CREATE TABLE `conyuges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `primer_apellido` varchar(200) NOT NULL,
  `segundo_apellido` varchar(200) NOT NULL,
  `nombres` varchar(200) NOT NULL,
  `tipo_identificacion` int(11) NOT NULL,
  `num_identificacion` int(11) NOT NULL,
  `fec_nacimiento` date NOT NULL,
  `actividad_laboral` int(11) NOT NULL,
  `salario` varchar(20) NOT NULL,
  `jornada_laboral` int(11) NOT NULL,
  `empresa` varchar(200) NOT NULL,
  `cargo` varchar(200) NOT NULL,
  `antiguedad` varchar(100) NOT NULL,
  `telefono` int(11) NOT NULL,
  `celular` int(11) NOT NULL,
  `nivel_escolar` int(11) NOT NULL,
  `ocupacion` varchar(200) NOT NULL,
  `asociado_fesun` int(11) NOT NULL,
  `persona_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `conyuges` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `fec_nacimiento`, `actividad_laboral`, `salario`, `jornada_laboral`, `empresa`, `cargo`, `antiguedad`, `telefono`, `celular`, `nivel_escolar`, `ocupacion`, `asociado_fesun`, `persona_id`) VALUES ('1', 'Salas', 'Torres', 'Sara', '1', '4545221', '0000-00-00', '1', '2000', '1', 'Empresa Soldadura', 'Recepcionista', '4 año', '45465564', '987878123', '2', 'Tecnica', '1', '3');
INSERT INTO `conyuges` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `fec_nacimiento`, `actividad_laboral`, `salario`, `jornada_laboral`, `empresa`, `cargo`, `antiguedad`, `telefono`, `celular`, `nivel_escolar`, `ocupacion`, `asociado_fesun`, `persona_id`) VALUES ('2', 'Salas', 'Torres', 'Sara', '1', '4545221', '0000-00-00', '1', '2000', '1', 'Empresa Soldadura', 'Recepcionista', '4 año', '45465564', '987878123', '2', 'Tecnica', '1', '4');
INSERT INTO `conyuges` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `fec_nacimiento`, `actividad_laboral`, `salario`, `jornada_laboral`, `empresa`, `cargo`, `antiguedad`, `telefono`, `celular`, `nivel_escolar`, `ocupacion`, `asociado_fesun`, `persona_id`) VALUES ('3', 'Salinas', 'sanchez', 'brenda', '1', '4545221', '2018-08-16', '2', '1000', '2', 'Empresa Soldadura', 'Recepcionista', '4 año', '45465564', '987878123', '4', 'Tecnica', '2', '5');
INSERT INTO `conyuges` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `fec_nacimiento`, `actividad_laboral`, `salario`, `jornada_laboral`, `empresa`, `cargo`, `antiguedad`, `telefono`, `celular`, `nivel_escolar`, `ocupacion`, `asociado_fesun`, `persona_id`) VALUES ('4', 'Aparicio', 'Romero', 'Carla', '1', '4545221', '1991-03-06', '2', '2000', '1', 'Empresa Soldadura', 'Recepcionista', '4 año', '45465564', '987878123', '5', 'Tecnica', '1', '6');
INSERT INTO `conyuges` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `fec_nacimiento`, `actividad_laboral`, `salario`, `jornada_laboral`, `empresa`, `cargo`, `antiguedad`, `telefono`, `celular`, `nivel_escolar`, `ocupacion`, `asociado_fesun`, `persona_id`) VALUES ('15', 'Salas', 'Torres', 'Sara', '1', '4545221', '1989-06-07', '2', '2000', '2', 'Empresa Soldadura', 'Recepcionista', '4 año', '45465564', '987878123', '2', 'Tecnica', '1', '7');
INSERT INTO `conyuges` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `fec_nacimiento`, `actividad_laboral`, `salario`, `jornada_laboral`, `empresa`, `cargo`, `antiguedad`, `telefono`, `celular`, `nivel_escolar`, `ocupacion`, `asociado_fesun`, `persona_id`) VALUES ('21', 'Salas', 'Torres', 'Sara', '2', '4545221', '2018-09-06', '2', '2000', '2', 'Empresa Soldadura', 'Recepcionista', '4 año', '45465564', '987878123', '6', 'Tecnica', '1', '6');
INSERT INTO `conyuges` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `fec_nacimiento`, `actividad_laboral`, `salario`, `jornada_laboral`, `empresa`, `cargo`, `antiguedad`, `telefono`, `celular`, `nivel_escolar`, `ocupacion`, `asociado_fesun`, `persona_id`) VALUES ('22', 'Medina', 'Torres', 'Sara', '1', '4545221', '2018-09-12', '1', '2000', '1', 'Empresa Soldadura', 'Recepcionista', '4 año', '45465564', '987878123', '6', 'Tecnica', '1', '7');
INSERT INTO `conyuges` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `fec_nacimiento`, `actividad_laboral`, `salario`, `jornada_laboral`, `empresa`, `cargo`, `antiguedad`, `telefono`, `celular`, `nivel_escolar`, `ocupacion`, `asociado_fesun`, `persona_id`) VALUES ('23', 'Caceres', 'Torres', 'Sara', '1', '4545221', '1989-06-07', '1', '2000', '1', 'Empresa Soldadura', 'Recepcionista', '4 año', '45465564', '987878123', '4', 'Tecnica', '1', '8');


#
# TABLE STRUCTURE FOR: departamentos
#

DROP TABLE IF EXISTS `departamentos`;

CREATE TABLE `departamentos` (
  `id_departamento` int(2) unsigned NOT NULL AUTO_INCREMENT,
  `departamento` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id_departamento`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4;

INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('5', 'ANTIOQUIA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('8', 'ATLÁNTICO');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('11', 'BOGOTÁ, D.C.');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('13', 'BOLÍVAR');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('15', 'BOYACÁ');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('17', 'CALDAS');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('18', 'CAQUETÁ');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('19', 'CAUCA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('20', 'CESAR');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('23', 'CÓRDOBA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('25', 'CUNDINAMARCA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('27', 'CHOCÓ');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('41', 'HUILA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('44', 'LA GUAJIRA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('47', 'MAGDALENA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('50', 'META');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('52', 'NARIÑO');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('54', 'NORTE DE SANTANDER');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('63', 'QUINDIO');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('66', 'RISARALDA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('68', 'SANTANDER');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('70', 'SUCRE');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('73', 'TOLIMA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('76', 'VALLE DEL CAUCA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('81', 'ARAUCA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('85', 'CASANARE');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('86', 'PUTUMAYO');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('88', 'ARCHIPIÉLAGO DE SAN ANDRÉS, PROVIDENCIA Y SANTA CATALINA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('91', 'AMAZONAS');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('94', 'GUAINÍA');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('95', 'GUAVIARE');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('97', 'VAUPÉS');
INSERT INTO `departamentos` (`id_departamento`, `departamento`) VALUES ('99', 'VICHADA');


#
# TABLE STRUCTURE FOR: descripcion_activos
#

DROP TABLE IF EXISTS `descripcion_activos`;

CREATE TABLE `descripcion_activos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `marca` varchar(50) NOT NULL,
  `modelo` varchar(50) NOT NULL,
  `placa` varchar(50) NOT NULL,
  `valor` varchar(50) NOT NULL,
  `pignoracion` varchar(100) NOT NULL,
  `entidad_pignorado` varchar(200) NOT NULL,
  `tipo_bien` varchar(200) NOT NULL,
  `direccion` varchar(200) NOT NULL,
  `departamento` int(11) NOT NULL,
  `ciudad` int(11) NOT NULL,
  `valor_comercial` varchar(20) NOT NULL,
  `matricula_inmobilaria` varchar(50) NOT NULL,
  `hipoteca` int(11) NOT NULL,
  `entidad_hipotecada` varchar(200) NOT NULL,
  `persona_id` int(11) NOT NULL,
  `otros_activos` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: estado_civil
#

DROP TABLE IF EXISTS `estado_civil`;

CREATE TABLE `estado_civil` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `estado_civil` (`id`, `nombre`) VALUES ('1', 'Soltero');
INSERT INTO `estado_civil` (`id`, `nombre`) VALUES ('2', 'Casado');
INSERT INTO `estado_civil` (`id`, `nombre`) VALUES ('3', 'Separado');
INSERT INTO `estado_civil` (`id`, `nombre`) VALUES ('4', 'Union Libre');
INSERT INTO `estado_civil` (`id`, `nombre`) VALUES ('5', 'Viudo');


#
# TABLE STRUCTURE FOR: familiares_asociados
#

DROP TABLE IF EXISTS `familiares_asociados`;

CREATE TABLE `familiares_asociados` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(250) NOT NULL,
  `parentesco` varchar(100) NOT NULL,
  `persona_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('1', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('2', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('3', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('4', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('5', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('6', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('7', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('8', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('9', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('10', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('11', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('12', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('13', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('14', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('15', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('16', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('17', '', '', '0');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('18', '', '', '6');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('19', '', '', '7');
INSERT INTO `familiares_asociados` (`id`, `nombres`, `parentesco`, `persona_id`) VALUES ('20', '', '', '8');


#
# TABLE STRUCTURE FOR: fincas
#

DROP TABLE IF EXISTS `fincas`;

CREATE TABLE `fincas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nit` varchar(50) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `direccion` varchar(150) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `descripcion` text NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('1', '98', 'ADMON QUINCENAL SUNSHINE', 'D', 'D', 'D', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('2', '02', 'EL CEREZO', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('3', '01', 'EL SECRETO', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('4', '02', 'SECRETO 2', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('5', '03', 'GASCUÑA', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('6', '04', 'ARENALES', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('7', '05', 'MONSERRATE', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('8', '06', 'EL JARDIN', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('9', '07', 'SAN ISIDRO', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('10', '08', 'CHIA', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('11', '10', 'BOUQUETERA COTA', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('12', '13', 'LA FUENTE', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('13', '14', 'CEREZO', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('14', '15', 'SARAMA', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('15', '16', 'EL ROCIO', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('16', '17', 'LAS CUADRAS', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('17', '18', 'BETANIA', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('18', '60', 'EL TESORO', '', '', '', '0');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('19', '20', 'BOUQ EL SECRETO', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('20', '21', 'BODEGA LA PUNTA', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('21', '22', 'SANTA FE', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('22', '23', 'EL RECUERDO', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('23', '28', 'BOUQ TENJO-CEREZO', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('24', '29', 'BOUQ EL CEREZO', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('25', '31', 'LA PRADERA', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('26', '32', 'BOUQ EL ROCIO', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('27', '33', 'BOUQ BETANIA', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('28', '50', 'MONTERROSA', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('29', '52', 'EL PORVENIR', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('30', '99', 'ADMON MENSUAL SUNSHINE', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('31', '98', 'ADMON QUINCENAL SUNSHINE', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('32', '19', 'FESUN', '', '', '', '1');
INSERT INTO `fincas` (`id`, `nit`, `nombre`, `direccion`, `telefono`, `descripcion`, `estado`) VALUES ('33', '22', 'SANTA FE', '', '', '', '1');


#
# TABLE STRUCTURE FOR: informacion_financiera
#

DROP TABLE IF EXISTS `informacion_financiera`;

CREATE TABLE `informacion_financiera` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ingreso_bruto` varchar(50) NOT NULL,
  `otros_ingresos` varchar(50) NOT NULL,
  `descripcion_ingresos` varchar(50) NOT NULL,
  `total_ingresos` varchar(50) NOT NULL,
  `prestamos` varchar(50) NOT NULL,
  `gastos_familiares` varchar(50) NOT NULL,
  `otros_gastos` varchar(50) NOT NULL,
  `total_egresos` varchar(50) NOT NULL,
  `bancos` varchar(50) NOT NULL,
  `corporaciones` varchar(50) NOT NULL,
  `personales` varchar(50) NOT NULL,
  `total_obligaciones` varchar(50) NOT NULL,
  `activos_propiedades` varchar(50) NOT NULL,
  `pasivos_obligaciones` varchar(50) NOT NULL,
  `cuenta_bancaria` int(11) NOT NULL,
  `entidad` varchar(200) NOT NULL,
  `tipo_cuenta` int(11) NOT NULL,
  `operaciones_extranjeras` int(11) NOT NULL,
  `pais` varchar(100) NOT NULL,
  `moneda_extranjera` int(11) NOT NULL,
  `banco` varchar(100) NOT NULL,
  `cuenta` varchar(100) NOT NULL,
  `declara_renta` int(11) NOT NULL,
  `persona_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO `informacion_financiera` (`id`, `ingreso_bruto`, `otros_ingresos`, `descripcion_ingresos`, `total_ingresos`, `prestamos`, `gastos_familiares`, `otros_gastos`, `total_egresos`, `bancos`, `corporaciones`, `personales`, `total_obligaciones`, `activos_propiedades`, `pasivos_obligaciones`, `cuenta_bancaria`, `entidad`, `tipo_cuenta`, `operaciones_extranjeras`, `pais`, `moneda_extranjera`, `banco`, `cuenta`, `declara_renta`, `persona_id`) VALUES ('1', '1500', '300', '300', '2100', '400', '300', '200', '900', '500', '200', '200', '900', '2000', '1500', '1', 'Banco Aztwa', '1', '2', '', '0', '', '', '1', '4');
INSERT INTO `informacion_financiera` (`id`, `ingreso_bruto`, `otros_ingresos`, `descripcion_ingresos`, `total_ingresos`, `prestamos`, `gastos_familiares`, `otros_gastos`, `total_egresos`, `bancos`, `corporaciones`, `personales`, `total_obligaciones`, `activos_propiedades`, `pasivos_obligaciones`, `cuenta_bancaria`, `entidad`, `tipo_cuenta`, `operaciones_extranjeras`, `pais`, `moneda_extranjera`, `banco`, `cuenta`, `declara_renta`, `persona_id`) VALUES ('12', '1500', '300', '300', '2100', '400', '300', '200', '900', '500', '200', '200', '900', '2000', '1500', '1', 'Banco Aztwa', '1', '2', '', '2', '', '', '1', '7');
INSERT INTO `informacion_financiera` (`id`, `ingreso_bruto`, `otros_ingresos`, `descripcion_ingresos`, `total_ingresos`, `prestamos`, `gastos_familiares`, `otros_gastos`, `total_egresos`, `bancos`, `corporaciones`, `personales`, `total_obligaciones`, `activos_propiedades`, `pasivos_obligaciones`, `cuenta_bancaria`, `entidad`, `tipo_cuenta`, `operaciones_extranjeras`, `pais`, `moneda_extranjera`, `banco`, `cuenta`, `declara_renta`, `persona_id`) VALUES ('18', '1500', '300', '300', '2100', '400', '300', '200', '900', '500', '200', '200', '900', '2000', '1500', '1', 'Banco Aztwa', '2', '1', 'colombia', '1', 'Banco Azteca', '12121-12112', '1', '6');
INSERT INTO `informacion_financiera` (`id`, `ingreso_bruto`, `otros_ingresos`, `descripcion_ingresos`, `total_ingresos`, `prestamos`, `gastos_familiares`, `otros_gastos`, `total_egresos`, `bancos`, `corporaciones`, `personales`, `total_obligaciones`, `activos_propiedades`, `pasivos_obligaciones`, `cuenta_bancaria`, `entidad`, `tipo_cuenta`, `operaciones_extranjeras`, `pais`, `moneda_extranjera`, `banco`, `cuenta`, `declara_renta`, `persona_id`) VALUES ('19', '1500', '300', '300', '2100', '400', '300', '200', '900', '500', '200', '200', '900', '2000', '1500', '1', 'Banco Aztwa', '1', '1', 'Mexico', '1', 'Banco Azteca', '1212-1212-1111', '1', '7');
INSERT INTO `informacion_financiera` (`id`, `ingreso_bruto`, `otros_ingresos`, `descripcion_ingresos`, `total_ingresos`, `prestamos`, `gastos_familiares`, `otros_gastos`, `total_egresos`, `bancos`, `corporaciones`, `personales`, `total_obligaciones`, `activos_propiedades`, `pasivos_obligaciones`, `cuenta_bancaria`, `entidad`, `tipo_cuenta`, `operaciones_extranjeras`, `pais`, `moneda_extranjera`, `banco`, `cuenta`, `declara_renta`, `persona_id`) VALUES ('20', '1500', '300', '300', '2100', '400', '300', '200', '900', '500', '200', '200', '900', '2000', '1500', '1', 'Banco Aztwa', '1', '1', 'Mexico', '2', '', '', '1', '8');


#
# TABLE STRUCTURE FOR: informacion_laboral
#

DROP TABLE IF EXISTS `informacion_laboral`;

CREATE TABLE `informacion_laboral` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vinculacion_empresa` varchar(100) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `finca` int(11) NOT NULL,
  `municipio` varchar(150) NOT NULL,
  `tipo_nomina` int(11) NOT NULL,
  `tipo_contrato` int(11) NOT NULL,
  `tiempo_servicio` varchar(100) NOT NULL,
  `sueldo_basico` varchar(100) NOT NULL,
  `cargo` varchar(100) NOT NULL,
  `fondo_pensiones` varchar(100) NOT NULL,
  `fondo_cesantias` varchar(100) NOT NULL,
  `observaciones` text NOT NULL,
  `persona_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO `informacion_laboral` (`id`, `vinculacion_empresa`, `fecha_ingreso`, `finca`, `municipio`, `tipo_nomina`, `tipo_contrato`, `tiempo_servicio`, `sueldo_basico`, `cargo`, `fondo_pensiones`, `fondo_cesantias`, `observaciones`, `persona_id`) VALUES ('1', 'Vinculado', '0000-00-00', '1', 'municipio01', '1', '1', '15 años', '4000', 'Recepcionista', '300', '400', 'Akgio en observaciones', '4');
INSERT INTO `informacion_laboral` (`id`, `vinculacion_empresa`, `fecha_ingreso`, `finca`, `municipio`, `tipo_nomina`, `tipo_contrato`, `tiempo_servicio`, `sueldo_basico`, `cargo`, `fondo_pensiones`, `fondo_cesantias`, `observaciones`, `persona_id`) VALUES ('12', 'Vinculado', '2018-01-02', '1', 'municipio01', '1', '1', '15 años', '4000', 'Recepcionista', '300', '400', 'observaciones laboral', '7');
INSERT INTO `informacion_laboral` (`id`, `vinculacion_empresa`, `fecha_ingreso`, `finca`, `municipio`, `tipo_nomina`, `tipo_contrato`, `tiempo_servicio`, `sueldo_basico`, `cargo`, `fondo_pensiones`, `fondo_cesantias`, `observaciones`, `persona_id`) VALUES ('18', 'Vinculado', '2018-09-21', '1', 'municipio01', '1', '1', '15 años', '4000', 'Recepcionista', '300', '400', 'observaciones', '6');
INSERT INTO `informacion_laboral` (`id`, `vinculacion_empresa`, `fecha_ingreso`, `finca`, `municipio`, `tipo_nomina`, `tipo_contrato`, `tiempo_servicio`, `sueldo_basico`, `cargo`, `fondo_pensiones`, `fondo_cesantias`, `observaciones`, `persona_id`) VALUES ('19', 'Vinculado', '1994-08-19', '1', 'municipio01', '1', '2', '15 años', '4000', 'Recepcionista', '300', '400', 'observaciones de informacion laboral', '7');
INSERT INTO `informacion_laboral` (`id`, `vinculacion_empresa`, `fecha_ingreso`, `finca`, `municipio`, `tipo_nomina`, `tipo_contrato`, `tiempo_servicio`, `sueldo_basico`, `cargo`, `fondo_pensiones`, `fondo_cesantias`, `observaciones`, `persona_id`) VALUES ('20', 'Vinculado', '2018-03-01', '1', 'municipio01', '1', '1', '15 años', '4000', 'Recepcionista', '300', '400', 'onservaciones informacion laboral', '8');


#
# TABLE STRUCTURE FOR: informacion_personal
#

DROP TABLE IF EXISTS `informacion_personal`;

CREATE TABLE `informacion_personal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `primer_apellido` varchar(200) NOT NULL,
  `segundo_apellido` varchar(200) NOT NULL,
  `nombres` varchar(200) NOT NULL,
  `tipo_identificacion` int(11) NOT NULL,
  `num_identificacion` int(11) NOT NULL,
  `departamento` int(11) NOT NULL,
  `municipio` int(11) NOT NULL,
  `genero` varchar(11) NOT NULL,
  `estado_civil` int(11) NOT NULL,
  `fec_expedicion` date NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `nivel_escolar` int(11) NOT NULL,
  `dep_nacimiento` int(11) NOT NULL,
  `mun_nacimiento` int(11) NOT NULL,
  `vivienda` int(11) NOT NULL,
  `profesion` varchar(150) NOT NULL,
  `ocupacion` varchar(150) NOT NULL,
  `numero_hijos` int(11) NOT NULL,
  `zona_ubicacion` int(11) NOT NULL,
  `tiempo_residencia` varchar(20) NOT NULL,
  `hijos_menores` int(11) NOT NULL,
  `cabeza_hogar` int(11) NOT NULL,
  `personas_dependientes` int(11) NOT NULL,
  `ciudad` varchar(200) NOT NULL,
  `direccion_residencia` varchar(200) NOT NULL,
  `barrio` varchar(150) NOT NULL,
  `celular` int(11) NOT NULL,
  `telefono` int(11) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `autorizo_envio` int(11) NOT NULL,
  `vinculado_fondo` int(11) NOT NULL,
  `nombre_entidad` varchar(200) DEFAULT NULL,
  `poblacion_vulnerable` int(11) NOT NULL,
  `tipo_poblacion` int(11) NOT NULL,
  `otra_poblacion` varchar(150) DEFAULT NULL,
  `maneja_recursos` int(11) NOT NULL,
  `reconocimiento` int(11) NOT NULL,
  `poder_publico` int(11) NOT NULL,
  `tiene_familiares` int(11) NOT NULL,
  `especificacion` text NOT NULL,
  `familiares_asociados` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `informacion_personal` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `departamento`, `municipio`, `genero`, `estado_civil`, `fec_expedicion`, `fecha_nacimiento`, `nivel_escolar`, `dep_nacimiento`, `mun_nacimiento`, `vivienda`, `profesion`, `ocupacion`, `numero_hijos`, `zona_ubicacion`, `tiempo_residencia`, `hijos_menores`, `cabeza_hogar`, `personas_dependientes`, `ciudad`, `direccion_residencia`, `barrio`, `celular`, `telefono`, `correo`, `autorizo_envio`, `vinculado_fondo`, `nombre_entidad`, `poblacion_vulnerable`, `tipo_poblacion`, `otra_poblacion`, `maneja_recursos`, `reconocimiento`, `poder_publico`, `tiene_familiares`, `especificacion`, `familiares_asociados`) VALUES ('6', 'quispe', 'gonzales', 'Carmen', '2', '45464641', '18', '555', 'M', '2', '2018-09-10', '2018-09-13', '6', '50', '699', '4', 'Ingeniero Civil', 'Gerente ', '4', '2', '5 años', '4', '1', '4', 'Mercaderes', 'Calle 202', 'Vereda Miraflores', '981121211', '988898989', 'luis@gmail.com', '1', '2', NULL, '1', '1', NULL, '0', '0', '0', '0', '', '0');
INSERT INTO `informacion_personal` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `departamento`, `municipio`, `genero`, `estado_civil`, `fec_expedicion`, `fecha_nacimiento`, `nivel_escolar`, `dep_nacimiento`, `mun_nacimiento`, `vivienda`, `profesion`, `ocupacion`, `numero_hijos`, `zona_ubicacion`, `tiempo_residencia`, `hijos_menores`, `cabeza_hogar`, `personas_dependientes`, `ciudad`, `direccion_residencia`, `barrio`, `celular`, `telefono`, `correo`, `autorizo_envio`, `vinculado_fondo`, `nombre_entidad`, `poblacion_vulnerable`, `tipo_poblacion`, `otra_poblacion`, `maneja_recursos`, `reconocimiento`, `poder_publico`, `tiene_familiares`, `especificacion`, `familiares_asociados`) VALUES ('7', 'Ceballos', 'Mamani', 'Juan Luis', '1', '46464545', '11', '107', 'M', '4', '2018-09-21', '2018-09-14', '6', '50', '501', '4', 'Ingeniero Civil', 'Gerente ', '4', '1', '5 años', '4', '1', '4', 'Mercaderes', 'Calle 202', 'Vereda Miraflores', '981121211', '988898989', 'luis@gmail.com', '2', '2', NULL, '2', '1', NULL, '0', '0', '0', '0', '', '0');
INSERT INTO `informacion_personal` (`id`, `primer_apellido`, `segundo_apellido`, `nombres`, `tipo_identificacion`, `num_identificacion`, `departamento`, `municipio`, `genero`, `estado_civil`, `fec_expedicion`, `fecha_nacimiento`, `nivel_escolar`, `dep_nacimiento`, `mun_nacimiento`, `vivienda`, `profesion`, `ocupacion`, `numero_hijos`, `zona_ubicacion`, `tiempo_residencia`, `hijos_menores`, `cabeza_hogar`, `personas_dependientes`, `ciudad`, `direccion_residencia`, `barrio`, `celular`, `telefono`, `correo`, `autorizo_envio`, `vinculado_fondo`, `nombre_entidad`, `poblacion_vulnerable`, `tipo_poblacion`, `otra_poblacion`, `maneja_recursos`, `reconocimiento`, `poder_publico`, `tiene_familiares`, `especificacion`, `familiares_asociados`) VALUES ('8', 'Arias', 'Baltazar', 'Carmen', '1', '12141213', '8', '677', 'M', '1', '2018-09-08', '1990-09-13', '6', '50', '501', '2', 'Ingeniero Civil', 'Gerente ', '4', '1', '5 años', '4', '1', '4', 'Mercaderes', 'Calle 202', 'Vereda Miraflores', '981121211', '988898989', 'luis@gmail.com', '1', '2', NULL, '1', '1', NULL, '0', '0', '0', '0', 'Especificaciones de informacion del personal', '0');


#
# TABLE STRUCTURE FOR: informacion_productos
#

DROP TABLE IF EXISTS `informacion_productos`;

CREATE TABLE `informacion_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ahorro_id` int(11) NOT NULL,
  `persona_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `informacion_productos` (`id`, `ahorro_id`, `persona_id`) VALUES ('12', '2', '7');
INSERT INTO `informacion_productos` (`id`, `ahorro_id`, `persona_id`) VALUES ('13', '4', '7');
INSERT INTO `informacion_productos` (`id`, `ahorro_id`, `persona_id`) VALUES ('14', '5', '7');
INSERT INTO `informacion_productos` (`id`, `ahorro_id`, `persona_id`) VALUES ('15', '2', '7');
INSERT INTO `informacion_productos` (`id`, `ahorro_id`, `persona_id`) VALUES ('16', '4', '7');
INSERT INTO `informacion_productos` (`id`, `ahorro_id`, `persona_id`) VALUES ('17', '2', '8');
INSERT INTO `informacion_productos` (`id`, `ahorro_id`, `persona_id`) VALUES ('18', '3', '8');


#
# TABLE STRUCTURE FOR: logs
#

DROP TABLE IF EXISTS `logs`;

CREATE TABLE `logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `modulo` varchar(150) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8;

INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('31', '2018-10-17 21:05:39', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('32', '2018-10-17 21:08:00', 'Usuarios', '2', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('33', '2018-10-17 21:15:11', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('34', '2018-10-17 23:21:50', 'Usuarios', '3', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('35', '2018-10-17 23:44:12', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('36', '2018-10-17 23:45:31', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('37', '2018-10-18 00:40:58', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('38', '2018-10-18 18:22:22', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('39', '2018-10-18 18:58:42', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('40', '2018-10-18 19:00:02', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('41', '2018-10-18 19:03:17', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('42', '2018-10-18 19:17:27', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('43', '2018-10-19 15:29:43', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('44', '2018-10-19 15:32:57', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('45', '2018-10-19 21:14:58', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('46', '2018-10-19 21:15:47', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('47', '2018-10-25 19:15:38', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('48', '2018-10-25 19:16:03', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('49', '2018-10-29 18:10:28', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('50', '2018-10-29 18:11:46', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('51', '2018-10-29 18:19:24', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('52', '2018-10-29 18:25:35', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('53', '2018-10-29 18:29:37', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('54', '2018-10-29 18:33:50', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('55', '2018-11-07 20:09:03', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('56', '2018-11-07 20:09:29', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('57', '2018-12-22 18:04:11', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('58', '2018-12-26 15:57:57', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('59', '2018-12-26 16:07:22', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('60', '2018-12-26 16:22:49', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('61', '2019-01-10 16:38:18', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('62', '2019-01-10 16:38:24', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('63', '2019-01-10 16:57:05', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('64', '2019-01-10 16:57:23', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('65', '2019-01-10 17:02:48', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('66', '2019-01-10 17:03:06', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('67', '2019-01-12 15:03:54', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('68', '2019-01-12 15:50:30', 'Fincas', '4', 'Inserción de la Finca EL SECRETO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('69', '2019-01-12 15:52:19', 'Fincas', '4', 'Inserción de la Finca SECRETO 2');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('70', '2019-01-12 15:52:33', 'Fincas', '4', 'Inserción de la Finca GASCUÑA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('71', '2019-01-12 15:52:46', 'Fincas', '4', 'Inserción de la Finca ARENALES');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('72', '2019-01-12 15:53:00', 'Fincas', '4', 'Inserción de la Finca MONSERRATE');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('73', '2019-01-12 15:53:29', 'Fincas', '4', 'Inserción de la Finca EL JARDIN');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('74', '2019-01-12 15:53:42', 'Fincas', '4', 'Inserción de la Finca SAN ISIDRO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('75', '2019-01-12 15:53:54', 'Fincas', '4', 'Inserción de la Finca CHIA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('76', '2019-01-12 15:54:28', 'Fincas', '4', 'Eliminación de la Finca Betania');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('77', '2019-01-12 15:54:39', 'Fincas', '4', 'Eliminación de la Finca Betania');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('78', '2019-01-12 15:54:54', 'Fincas', '4', 'Eliminación de la Finca El Cerezo');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('79', '2019-01-12 15:55:26', 'Fincas', '4', 'Inserción de la Finca BOUQUETERA COTA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('80', '2019-01-12 15:55:44', 'Fincas', '4', 'Inserción de la Finca LA FUENTE');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('81', '2019-01-12 15:56:09', 'Fincas', '4', 'Inserción de la Finca CEREZO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('82', '2019-01-12 15:56:27', 'Fincas', '4', 'Inserción de la Finca SARAMA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('83', '2019-01-12 15:56:46', 'Fincas', '4', 'Inserción de la Finca EL ROCIO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('84', '2019-01-12 15:57:05', 'Fincas', '4', 'Inserción de la Finca LAS CUADRAS');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('85', '2019-01-12 15:57:45', 'Fincas', '4', 'Inserción de la Finca BETANIA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('86', '2019-01-12 15:57:50', 'Fincas', '4', 'Inserción de la Finca BETANIA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('87', '2019-01-12 15:58:33', 'Fincas', '4', 'Eliminación de la Finca BETANIA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('88', '2019-01-12 15:59:15', 'Fincas', '4', 'Actualización de la Finca BETANIA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('89', '2019-01-12 15:59:44', 'Fincas', '4', 'Inserción de la Finca BOUQ EL SECRETO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('90', '2019-01-12 16:00:16', 'Fincas', '4', 'Inserción de la Finca BODEGA LA PUNTA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('91', '2019-01-12 16:00:37', 'Fincas', '4', 'Inserción de la Finca BODEGA LA PUNTA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('92', '2019-01-12 16:01:23', 'Fincas', '4', 'Inserción de la Finca EL RECUERDO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('93', '2019-01-12 16:05:25', 'Fincas', '4', 'Inserción de la Finca BOUQ TENJO-CEREZO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('94', '2019-01-12 16:05:58', 'Fincas', '4', 'Inserción de la Finca BOUQ EL CEREZO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('95', '2019-01-12 16:06:20', 'Fincas', '4', 'Inserción de la Finca LA PRADERA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('96', '2019-01-12 16:06:45', 'Fincas', '4', 'Inserción de la Finca BOUQ EL ROCIO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('97', '2019-01-12 16:07:08', 'Fincas', '4', 'Inserción de la Finca BOUQ BETANIA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('98', '2019-01-12 16:07:38', 'Fincas', '4', 'Inserción de la Finca MONTERROSA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('99', '2019-01-12 16:08:08', 'Fincas', '4', 'Inserción de la Finca EL PORVENIR');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('100', '2019-01-12 16:08:52', 'Fincas', '4', 'Inserción de la Finca ADMON MENSUAL SUNSHINE');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('101', '2019-01-12 16:09:25', 'Fincas', '4', 'Inserción de la Finca ADMON QUINCENAL SUNSHINE');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('102', '2019-01-12 16:10:20', 'Fincas', '4', 'Inserción de la Finca FESUN');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('103', '2019-01-12 16:24:08', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('104', '2019-01-12 16:49:03', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('105', '2019-01-12 16:53:12', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('106', '2019-01-12 16:55:26', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('107', '2019-01-12 18:58:17', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('108', '2019-01-12 18:59:03', 'Fincas', '1', 'Actualización de la Finca BETANIA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('109', '2019-01-12 18:59:19', 'Fincas', '1', 'Actualización de la Finca EL CEREZO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('110', '2019-01-12 18:59:29', 'Fincas', '1', 'Actualización de la Finca BETANIA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('111', '2019-01-12 19:00:08', 'Fincas', '1', 'Actualización de la Finca EL CEREZO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('112', '2019-01-14 14:25:37', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('113', '2019-01-14 14:38:25', 'Usuarios', '4', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('114', '2019-01-14 14:53:11', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('115', '2019-01-14 14:55:47', 'Usuarios', '6', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('116', '2019-01-14 15:02:07', 'Usuarios', '6', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('117', '2019-01-14 15:06:15', 'Usuarios', '4', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('118', '2019-01-14 15:06:22', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('119', '2019-01-14 15:07:10', 'Usuarios', '1', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('120', '2019-01-14 15:37:26', 'Usuarios', '6', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('121', '2019-01-14 15:37:32', 'Usuarios', '6', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('122', '2019-01-14 16:12:53', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('123', '2019-01-14 16:15:51', 'Fincas', '1', 'Eliminación de la Finca BETANIA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('124', '2019-01-14 16:17:51', 'Fincas', '1', 'Eliminación de la Finca BETANIA');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('125', '2019-01-14 16:18:31', 'Fincas', '1', 'Actualización de la Finca PUEBLO VIEJO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('126', '2019-01-14 16:19:24', 'Fincas', '1', 'Actualización de la Finca EL TESORO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('127', '2019-01-14 16:26:19', 'Fincas', '1', 'Inserción de la Finca SANTA FE');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('128', '2019-01-14 16:42:24', 'Fincas', '1', 'Actualización de la Finca SANTA FE');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('129', '2019-01-14 17:31:43', 'Usuarios', '6', 'Cierre de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('130', '2019-01-14 17:31:53', 'Usuarios', '6', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('131', '2019-01-14 19:35:43', 'Usuarios', '6', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('132', '2019-01-14 20:11:47', 'Usuarios', '1', 'Inicio de sesión');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('133', '2019-01-14 20:46:35', 'Fincas', '1', 'Eliminación de la Finca PUEBLO VIEJO');
INSERT INTO `logs` (`id`, `fecha`, `modulo`, `usuario_id`, `descripcion`) VALUES ('134', '2019-01-14 20:47:09', 'Fincas', '1', 'Actualización de la Finca ADMON QUINCENAL SUNSHINE');


#
# TABLE STRUCTURE FOR: municipios
#

DROP TABLE IF EXISTS `municipios`;

CREATE TABLE `municipios` (
  `id_municipio` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `municipio` varchar(255) NOT NULL DEFAULT '',
  `estado` int(1) unsigned NOT NULL,
  `departamento_id` int(2) unsigned NOT NULL,
  PRIMARY KEY (`id_municipio`),
  KEY `departamento_id` (`departamento_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1101 DEFAULT CHARSET=utf8mb4;

INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1', 'Abriaquí', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('2', 'Acacías', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('3', 'Acandí', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('4', 'Acevedo', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('5', 'Achí', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('6', 'Agrado', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('7', 'Agua de Dios', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('8', 'Aguachica', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('9', 'Aguada', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('10', 'Aguadas', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('11', 'Aguazul', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('12', 'Agustín Codazzi', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('13', 'Aipe', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('14', 'Albania', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('15', 'Albania', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('16', 'Albania', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('17', 'Albán', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('18', 'Albán (San José)', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('19', 'Alcalá', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('20', 'Alejandria', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('21', 'Algarrobo', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('22', 'Algeciras', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('23', 'Almaguer', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('24', 'Almeida', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('25', 'Alpujarra', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('26', 'Altamira', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('27', 'Alto Baudó (Pie de Pato)', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('28', 'Altos del Rosario', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('29', 'Alvarado', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('30', 'Amagá', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('31', 'Amalfi', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('32', 'Ambalema', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('33', 'Anapoima', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('34', 'Ancuya', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('35', 'Andalucía', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('36', 'Andes', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('37', 'Angelópolis', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('38', 'Angostura', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('39', 'Anolaima', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('40', 'Anorí', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('41', 'Anserma', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('42', 'Ansermanuevo', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('43', 'Anzoátegui', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('44', 'Anzá', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('45', 'Apartadó', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('46', 'Apulo', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('47', 'Apía', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('48', 'Aquitania', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('49', 'Aracataca', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('50', 'Aranzazu', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('51', 'Aratoca', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('52', 'Arauca', '1', '81');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('53', 'Arauquita', '1', '81');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('54', 'Arbeláez', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('55', 'Arboleda (Berruecos)', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('56', 'Arboledas', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('57', 'Arboletes', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('58', 'Arcabuco', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('59', 'Arenal', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('60', 'Argelia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('61', 'Argelia', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('62', 'Argelia', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('63', 'Ariguaní (El Difícil)', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('64', 'Arjona', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('65', 'Armenia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('66', 'Armenia', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('67', 'Armero (Guayabal)', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('68', 'Arroyohondo', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('69', 'Astrea', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('70', 'Ataco', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('71', 'Atrato (Yuto)', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('72', 'Ayapel', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('73', 'Bagadó', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('74', 'Bahía Solano (Mútis)', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('75', 'Bajo Baudó (Pizarro)', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('76', 'Balboa', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('77', 'Balboa', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('78', 'Baranoa', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('79', 'Baraya', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('80', 'Barbacoas', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('81', 'Barbosa', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('82', 'Barbosa', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('83', 'Barichara', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('84', 'Barranca de Upía', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('85', 'Barrancabermeja', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('86', 'Barrancas', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('87', 'Barranco de Loba', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('88', 'Barranquilla', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('89', 'Becerríl', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('90', 'Belalcázar', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('91', 'Bello', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('92', 'Belmira', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('93', 'Beltrán', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('94', 'Belén', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('95', 'Belén', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('96', 'Belén de Bajirá', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('97', 'Belén de Umbría', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('98', 'Belén de los Andaquíes', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('99', 'Berbeo', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('100', 'Betania', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('101', 'Beteitiva', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('102', 'Betulia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('103', 'Betulia', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('104', 'Bituima', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('105', 'Boavita', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('106', 'Bochalema', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('107', 'Bogotá D.C.', '1', '11');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('108', 'Bojacá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('109', 'Bojayá (Bellavista)', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('110', 'Bolívar', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('111', 'Bolívar', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('112', 'Bolívar', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('113', 'Bolívar', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('114', 'Bosconia', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('115', 'Boyacá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('116', 'Briceño', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('117', 'Briceño', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('118', 'Bucaramanga', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('119', 'Bucarasica', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('120', 'Buenaventura', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('121', 'Buenavista', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('122', 'Buenavista', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('123', 'Buenavista', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('124', 'Buenavista', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('125', 'Buenos Aires', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('126', 'Buesaco', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('127', 'Buga', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('128', 'Bugalagrande', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('129', 'Burítica', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('130', 'Busbanza', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('131', 'Cabrera', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('132', 'Cabrera', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('133', 'Cabuyaro', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('134', 'Cachipay', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('135', 'Caicedo', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('136', 'Caicedonia', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('137', 'Caimito', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('138', 'Cajamarca', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('139', 'Cajibío', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('140', 'Cajicá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('141', 'Calamar', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('142', 'Calamar', '1', '95');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('143', 'Calarcá', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('144', 'Caldas', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('145', 'Caldas', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('146', 'Caldono', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('147', 'California', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('148', 'Calima (Darién)', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('149', 'Caloto', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('150', 'Calí', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('151', 'Campamento', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('152', 'Campo de la Cruz', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('153', 'Campoalegre', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('154', 'Campohermoso', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('155', 'Canalete', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('156', 'Candelaria', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('157', 'Candelaria', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('158', 'Cantagallo', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('159', 'Cantón de San Pablo', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('160', 'Caparrapí', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('161', 'Capitanejo', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('162', 'Caracolí', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('163', 'Caramanta', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('164', 'Carcasí', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('165', 'Carepa', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('166', 'Carmen de Apicalá', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('167', 'Carmen de Carupa', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('168', 'Carmen de Viboral', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('169', 'Carmen del Darién (CURBARADÓ)', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('170', 'Carolina', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('171', 'Cartagena', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('172', 'Cartagena del Chairá', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('173', 'Cartago', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('174', 'Carurú', '1', '97');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('175', 'Casabianca', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('176', 'Castilla la Nueva', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('177', 'Caucasia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('178', 'Cañasgordas', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('179', 'Cepita', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('180', 'Cereté', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('181', 'Cerinza', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('182', 'Cerrito', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('183', 'Cerro San Antonio', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('184', 'Chachaguí', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('185', 'Chaguaní', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('186', 'Chalán', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('187', 'Chaparral', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('188', 'Charalá', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('189', 'Charta', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('190', 'Chigorodó', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('191', 'Chima', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('192', 'Chimichagua', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('193', 'Chimá', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('194', 'Chinavita', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('195', 'Chinchiná', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('196', 'Chinácota', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('197', 'Chinú', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('198', 'Chipaque', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('199', 'Chipatá', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('200', 'Chiquinquirá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('201', 'Chiriguaná', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('202', 'Chiscas', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('203', 'Chita', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('204', 'Chitagá', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('205', 'Chitaraque', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('206', 'Chivatá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('207', 'Chivolo', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('208', 'Choachí', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('209', 'Chocontá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('210', 'Chámeza', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('211', 'Chía', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('212', 'Chíquiza', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('213', 'Chívor', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('214', 'Cicuco', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('215', 'Cimitarra', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('216', 'Circasia', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('217', 'Cisneros', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('218', 'Ciénaga', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('219', 'Ciénaga', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('220', 'Ciénaga de Oro', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('221', 'Clemencia', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('222', 'Cocorná', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('223', 'Coello', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('224', 'Cogua', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('225', 'Colombia', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('226', 'Colosó (Ricaurte)', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('227', 'Colón', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('228', 'Colón (Génova)', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('229', 'Concepción', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('230', 'Concepción', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('231', 'Concordia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('232', 'Concordia', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('233', 'Condoto', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('234', 'Confines', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('235', 'Consaca', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('236', 'Contadero', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('237', 'Contratación', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('238', 'Convención', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('239', 'Copacabana', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('240', 'Coper', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('241', 'Cordobá', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('242', 'Corinto', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('243', 'Coromoro', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('244', 'Corozal', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('245', 'Corrales', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('246', 'Cota', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('247', 'Cotorra', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('248', 'Covarachía', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('249', 'Coveñas', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('250', 'Coyaima', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('251', 'Cravo Norte', '1', '81');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('252', 'Cuaspud (Carlosama)', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('253', 'Cubarral', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('254', 'Cubará', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('255', 'Cucaita', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('256', 'Cucunubá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('257', 'Cucutilla', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('258', 'Cuitiva', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('259', 'Cumaral', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('260', 'Cumaribo', '1', '99');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('261', 'Cumbal', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('262', 'Cumbitara', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('263', 'Cunday', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('264', 'Curillo', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('265', 'Curití', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('266', 'Curumaní', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('267', 'Cáceres', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('268', 'Cáchira', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('269', 'Cácota', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('270', 'Cáqueza', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('271', 'Cértegui', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('272', 'Cómbita', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('273', 'Córdoba', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('274', 'Córdoba', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('275', 'Cúcuta', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('276', 'Dabeiba', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('277', 'Dagua', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('278', 'Dibulla', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('279', 'Distracción', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('280', 'Dolores', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('281', 'Don Matías', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('282', 'Dos Quebradas', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('283', 'Duitama', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('284', 'Durania', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('285', 'Ebéjico', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('286', 'El Bagre', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('287', 'El Banco', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('288', 'El Cairo', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('289', 'El Calvario', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('290', 'El Carmen', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('291', 'El Carmen', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('292', 'El Carmen de Atrato', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('293', 'El Carmen de Bolívar', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('294', 'El Castillo', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('295', 'El Cerrito', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('296', 'El Charco', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('297', 'El Cocuy', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('298', 'El Colegio', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('299', 'El Copey', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('300', 'El Doncello', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('301', 'El Dorado', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('302', 'El Dovio', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('303', 'El Espino', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('304', 'El Guacamayo', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('305', 'El Guamo', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('306', 'El Molino', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('307', 'El Paso', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('308', 'El Paujil', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('309', 'El Peñol', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('310', 'El Peñon', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('311', 'El Peñon', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('312', 'El Peñón', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('313', 'El Piñon', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('314', 'El Playón', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('315', 'El Retorno', '1', '95');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('316', 'El Retén', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('317', 'El Roble', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('318', 'El Rosal', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('319', 'El Rosario', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('320', 'El Tablón de Gómez', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('321', 'El Tambo', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('322', 'El Tambo', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('323', 'El Tarra', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('324', 'El Zulia', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('325', 'El Águila', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('326', 'Elías', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('327', 'Encino', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('328', 'Enciso', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('329', 'Entrerríos', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('330', 'Envigado', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('331', 'Espinal', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('332', 'Facatativá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('333', 'Falan', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('334', 'Filadelfia', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('335', 'Filandia', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('336', 'Firavitoba', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('337', 'Flandes', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('338', 'Florencia', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('339', 'Florencia', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('340', 'Floresta', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('341', 'Florida', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('342', 'Floridablanca', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('343', 'Florián', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('344', 'Fonseca', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('345', 'Fortúl', '1', '81');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('346', 'Fosca', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('347', 'Francisco Pizarro', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('348', 'Fredonia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('349', 'Fresno', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('350', 'Frontino', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('351', 'Fuente de Oro', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('352', 'Fundación', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('353', 'Funes', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('354', 'Funza', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('355', 'Fusagasugá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('356', 'Fómeque', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('357', 'Fúquene', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('358', 'Gachalá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('359', 'Gachancipá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('360', 'Gachantivá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('361', 'Gachetá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('362', 'Galapa', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('363', 'Galeras (Nueva Granada)', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('364', 'Galán', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('365', 'Gama', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('366', 'Gamarra', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('367', 'Garagoa', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('368', 'Garzón', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('369', 'Gigante', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('370', 'Ginebra', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('371', 'Giraldo', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('372', 'Girardot', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('373', 'Girardota', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('374', 'Girón', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('375', 'Gonzalez', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('376', 'Gramalote', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('377', 'Granada', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('378', 'Granada', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('379', 'Granada', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('380', 'Guaca', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('381', 'Guacamayas', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('382', 'Guacarí', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('383', 'Guachavés', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('384', 'Guachené', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('385', 'Guachetá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('386', 'Guachucal', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('387', 'Guadalupe', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('388', 'Guadalupe', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('389', 'Guadalupe', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('390', 'Guaduas', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('391', 'Guaitarilla', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('392', 'Gualmatán', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('393', 'Guamal', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('394', 'Guamal', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('395', 'Guamo', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('396', 'Guapota', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('397', 'Guapí', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('398', 'Guaranda', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('399', 'Guarne', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('400', 'Guasca', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('401', 'Guatapé', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('402', 'Guataquí', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('403', 'Guatavita', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('404', 'Guateque', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('405', 'Guavatá', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('406', 'Guayabal de Siquima', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('407', 'Guayabetal', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('408', 'Guayatá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('409', 'Guepsa', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('410', 'Guicán', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('411', 'Gutiérrez', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('412', 'Guática', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('413', 'Gámbita', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('414', 'Gámeza', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('415', 'Génova', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('416', 'Gómez Plata', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('417', 'Hacarí', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('418', 'Hatillo de Loba', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('419', 'Hato', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('420', 'Hato Corozal', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('421', 'Hatonuevo', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('422', 'Heliconia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('423', 'Herrán', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('424', 'Herveo', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('425', 'Hispania', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('426', 'Hobo', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('427', 'Honda', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('428', 'Ibagué', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('429', 'Icononzo', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('430', 'Iles', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('431', 'Imúes', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('432', 'Inzá', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('433', 'Inírida', '1', '94');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('434', 'Ipiales', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('435', 'Isnos', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('436', 'Istmina', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('437', 'Itagüí', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('438', 'Ituango', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('439', 'Izá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('440', 'Jambaló', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('441', 'Jamundí', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('442', 'Jardín', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('443', 'Jenesano', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('444', 'Jericó', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('445', 'Jericó', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('446', 'Jerusalén', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('447', 'Jesús María', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('448', 'Jordán', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('449', 'Juan de Acosta', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('450', 'Junín', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('451', 'Juradó', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('452', 'La Apartada y La Frontera', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('453', 'La Argentina', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('454', 'La Belleza', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('455', 'La Calera', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('456', 'La Capilla', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('457', 'La Ceja', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('458', 'La Celia', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('459', 'La Cruz', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('460', 'La Cumbre', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('461', 'La Dorada', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('462', 'La Esperanza', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('463', 'La Estrella', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('464', 'La Florida', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('465', 'La Gloria', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('466', 'La Jagua de Ibirico', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('467', 'La Jagua del Pilar', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('468', 'La Llanada', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('469', 'La Macarena', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('470', 'La Merced', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('471', 'La Mesa', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('472', 'La Montañita', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('473', 'La Palma', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('474', 'La Paz', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('475', 'La Paz (Robles)', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('476', 'La Peña', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('477', 'La Pintada', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('478', 'La Plata', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('479', 'La Playa', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('480', 'La Primavera', '1', '99');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('481', 'La Salina', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('482', 'La Sierra', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('483', 'La Tebaida', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('484', 'La Tola', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('485', 'La Unión', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('486', 'La Unión', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('487', 'La Unión', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('488', 'La Unión', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('489', 'La Uvita', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('490', 'La Vega', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('491', 'La Vega', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('492', 'La Victoria', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('493', 'La Victoria', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('494', 'La Victoria', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('495', 'La Virginia', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('496', 'Labateca', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('497', 'Labranzagrande', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('498', 'Landázuri', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('499', 'Lebrija', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('500', 'Leiva', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('501', 'Lejanías', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('502', 'Lenguazaque', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('503', 'Leticia', '1', '91');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('504', 'Liborina', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('505', 'Linares', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('506', 'Lloró', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('507', 'Lorica', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('508', 'Los Córdobas', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('509', 'Los Palmitos', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('510', 'Los Patios', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('511', 'Los Santos', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('512', 'Lourdes', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('513', 'Luruaco', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('514', 'Lérida', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('515', 'Líbano', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('516', 'López (Micay)', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('517', 'Macanal', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('518', 'Macaravita', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('519', 'Maceo', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('520', 'Machetá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('521', 'Madrid', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('522', 'Magangué', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('523', 'Magüi (Payán)', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('524', 'Mahates', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('525', 'Maicao', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('526', 'Majagual', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('527', 'Malambo', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('528', 'Mallama (Piedrancha)', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('529', 'Manatí', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('530', 'Manaure', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('531', 'Manaure Balcón del Cesar', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('532', 'Manizales', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('533', 'Manta', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('534', 'Manzanares', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('535', 'Maní', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('536', 'Mapiripan', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('537', 'Margarita', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('538', 'Marinilla', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('539', 'Maripí', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('540', 'Mariquita', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('541', 'Marmato', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('542', 'Marquetalia', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('543', 'Marsella', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('544', 'Marulanda', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('545', 'María la Baja', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('546', 'Matanza', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('547', 'Medellín', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('548', 'Medina', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('549', 'Medio Atrato', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('550', 'Medio Baudó', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('551', 'Medio San Juan (ANDAGOYA)', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('552', 'Melgar', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('553', 'Mercaderes', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('554', 'Mesetas', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('555', 'Milán', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('556', 'Miraflores', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('557', 'Miraflores', '1', '95');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('558', 'Miranda', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('559', 'Mistrató', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('560', 'Mitú', '1', '97');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('561', 'Mocoa', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('562', 'Mogotes', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('563', 'Molagavita', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('564', 'Momil', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('565', 'Mompós', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('566', 'Mongua', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('567', 'Monguí', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('568', 'Moniquirá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('569', 'Montebello', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('570', 'Montecristo', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('571', 'Montelíbano', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('572', 'Montenegro', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('573', 'Monteria', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('574', 'Monterrey', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('575', 'Morales', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('576', 'Morales', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('577', 'Morelia', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('578', 'Morroa', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('579', 'Mosquera', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('580', 'Mosquera', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('581', 'Motavita', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('582', 'Moñitos', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('583', 'Murillo', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('584', 'Murindó', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('585', 'Mutatá', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('586', 'Mutiscua', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('587', 'Muzo', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('588', 'Málaga', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('589', 'Nariño', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('590', 'Nariño', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('591', 'Nariño', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('592', 'Natagaima', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('593', 'Nechí', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('594', 'Necoclí', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('595', 'Neira', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('596', 'Neiva', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('597', 'Nemocón', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('598', 'Nilo', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('599', 'Nimaima', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('600', 'Nobsa', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('601', 'Nocaima', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('602', 'Norcasia', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('603', 'Norosí', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('604', 'Novita', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('605', 'Nueva Granada', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('606', 'Nuevo Colón', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('607', 'Nunchía', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('608', 'Nuquí', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('609', 'Nátaga', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('610', 'Obando', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('611', 'Ocamonte', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('612', 'Ocaña', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('613', 'Oiba', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('614', 'Oicatá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('615', 'Olaya', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('616', 'Olaya Herrera', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('617', 'Onzaga', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('618', 'Oporapa', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('619', 'Orito', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('620', 'Orocué', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('621', 'Ortega', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('622', 'Ospina', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('623', 'Otanche', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('624', 'Ovejas', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('625', 'Pachavita', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('626', 'Pacho', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('627', 'Padilla', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('628', 'Paicol', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('629', 'Pailitas', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('630', 'Paime', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('631', 'Paipa', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('632', 'Pajarito', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('633', 'Palermo', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('634', 'Palestina', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('635', 'Palestina', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('636', 'Palmar', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('637', 'Palmar de Varela', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('638', 'Palmas del Socorro', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('639', 'Palmira', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('640', 'Palmito', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('641', 'Palocabildo', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('642', 'Pamplona', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('643', 'Pamplonita', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('644', 'Pandi', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('645', 'Panqueba', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('646', 'Paratebueno', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('647', 'Pasca', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('648', 'Patía (El Bordo)', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('649', 'Pauna', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('650', 'Paya', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('651', 'Paz de Ariporo', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('652', 'Paz de Río', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('653', 'Pedraza', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('654', 'Pelaya', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('655', 'Pensilvania', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('656', 'Peque', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('657', 'Pereira', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('658', 'Pesca', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('659', 'Peñol', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('660', 'Piamonte', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('661', 'Pie de Cuesta', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('662', 'Piedras', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('663', 'Piendamó', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('664', 'Pijao', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('665', 'Pijiño', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('666', 'Pinchote', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('667', 'Pinillos', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('668', 'Piojo', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('669', 'Pisva', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('670', 'Pital', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('671', 'Pitalito', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('672', 'Pivijay', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('673', 'Planadas', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('674', 'Planeta Rica', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('675', 'Plato', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('676', 'Policarpa', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('677', 'Polonuevo', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('678', 'Ponedera', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('679', 'Popayán', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('680', 'Pore', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('681', 'Potosí', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('682', 'Pradera', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('683', 'Prado', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('684', 'Providencia', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('685', 'Providencia', '1', '88');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('686', 'Pueblo Bello', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('687', 'Pueblo Nuevo', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('688', 'Pueblo Rico', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('689', 'Pueblorrico', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('690', 'Puebloviejo', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('691', 'Puente Nacional', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('692', 'Puerres', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('693', 'Puerto Asís', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('694', 'Puerto Berrío', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('695', 'Puerto Boyacá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('696', 'Puerto Caicedo', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('697', 'Puerto Carreño', '1', '99');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('698', 'Puerto Colombia', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('699', 'Puerto Concordia', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('700', 'Puerto Escondido', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('701', 'Puerto Gaitán', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('702', 'Puerto Guzmán', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('703', 'Puerto Leguízamo', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('704', 'Puerto Libertador', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('705', 'Puerto Lleras', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('706', 'Puerto López', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('707', 'Puerto Nare', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('708', 'Puerto Nariño', '1', '91');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('709', 'Puerto Parra', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('710', 'Puerto Rico', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('711', 'Puerto Rico', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('712', 'Puerto Rondón', '1', '81');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('713', 'Puerto Salgar', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('714', 'Puerto Santander', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('715', 'Puerto Tejada', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('716', 'Puerto Triunfo', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('717', 'Puerto Wilches', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('718', 'Pulí', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('719', 'Pupiales', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('720', 'Puracé (Coconuco)', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('721', 'Purificación', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('722', 'Purísima', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('723', 'Pácora', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('724', 'Páez', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('725', 'Páez (Belalcazar)', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('726', 'Páramo', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('727', 'Quebradanegra', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('728', 'Quetame', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('729', 'Quibdó', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('730', 'Quimbaya', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('731', 'Quinchía', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('732', 'Quipama', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('733', 'Quipile', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('734', 'Ragonvalia', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('735', 'Ramiriquí', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('736', 'Recetor', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('737', 'Regidor', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('738', 'Remedios', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('739', 'Remolino', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('740', 'Repelón', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('741', 'Restrepo', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('742', 'Restrepo', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('743', 'Retiro', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('744', 'Ricaurte', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('745', 'Ricaurte', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('746', 'Rio Negro', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('747', 'Rioblanco', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('748', 'Riofrío', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('749', 'Riohacha', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('750', 'Risaralda', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('751', 'Rivera', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('752', 'Roberto Payán (San José)', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('753', 'Roldanillo', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('754', 'Roncesvalles', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('755', 'Rondón', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('756', 'Rosas', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('757', 'Rovira', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('758', 'Ráquira', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('759', 'Río Iró', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('760', 'Río Quito', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('761', 'Río Sucio', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('762', 'Río Viejo', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('763', 'Río de oro', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('764', 'Ríonegro', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('765', 'Ríosucio', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('766', 'Sabana de Torres', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('767', 'Sabanagrande', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('768', 'Sabanalarga', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('769', 'Sabanalarga', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('770', 'Sabanalarga', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('771', 'Sabanas de San Angel (SAN ANGEL)', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('772', 'Sabaneta', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('773', 'Saboyá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('774', 'Sahagún', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('775', 'Saladoblanco', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('776', 'Salamina', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('777', 'Salamina', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('778', 'Salazar', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('779', 'Saldaña', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('780', 'Salento', '1', '63');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('781', 'Salgar', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('782', 'Samacá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('783', 'Samaniego', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('784', 'Samaná', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('785', 'Sampués', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('786', 'San Agustín', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('787', 'San Alberto', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('788', 'San Andrés', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('789', 'San Andrés Sotavento', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('790', 'San Andrés de Cuerquía', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('791', 'San Antero', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('792', 'San Antonio', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('793', 'San Antonio de Tequendama', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('794', 'San Benito', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('795', 'San Benito Abad', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('796', 'San Bernardo', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('797', 'San Bernardo', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('798', 'San Bernardo del Viento', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('799', 'San Calixto', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('800', 'San Carlos', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('801', 'San Carlos', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('802', 'San Carlos de Guaroa', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('803', 'San Cayetano', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('804', 'San Cayetano', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('805', 'San Cristobal', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('806', 'San Diego', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('807', 'San Eduardo', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('808', 'San Estanislao', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('809', 'San Fernando', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('810', 'San Francisco', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('811', 'San Francisco', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('812', 'San Francisco', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('813', 'San Gíl', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('814', 'San Jacinto', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('815', 'San Jacinto del Cauca', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('816', 'San Jerónimo', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('817', 'San Joaquín', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('818', 'San José', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('819', 'San José de Miranda', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('820', 'San José de Montaña', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('821', 'San José de Pare', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('822', 'San José de Uré', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('823', 'San José del Fragua', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('824', 'San José del Guaviare', '1', '95');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('825', 'San José del Palmar', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('826', 'San Juan de Arama', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('827', 'San Juan de Betulia', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('828', 'San Juan de Nepomuceno', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('829', 'San Juan de Pasto', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('830', 'San Juan de Río Seco', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('831', 'San Juan de Urabá', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('832', 'San Juan del Cesar', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('833', 'San Juanito', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('834', 'San Lorenzo', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('835', 'San Luis', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('836', 'San Luís', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('837', 'San Luís de Gaceno', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('838', 'San Luís de Palenque', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('839', 'San Marcos', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('840', 'San Martín', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('841', 'San Martín', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('842', 'San Martín de Loba', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('843', 'San Mateo', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('844', 'San Miguel', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('845', 'San Miguel', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('846', 'San Miguel de Sema', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('847', 'San Onofre', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('848', 'San Pablo', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('849', 'San Pablo', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('850', 'San Pablo de Borbur', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('851', 'San Pedro', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('852', 'San Pedro', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('853', 'San Pedro', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('854', 'San Pedro de Cartago', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('855', 'San Pedro de Urabá', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('856', 'San Pelayo', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('857', 'San Rafael', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('858', 'San Roque', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('859', 'San Sebastián', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('860', 'San Sebastián de Buenavista', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('861', 'San Vicente', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('862', 'San Vicente del Caguán', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('863', 'San Vicente del Chucurí', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('864', 'San Zenón', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('865', 'Sandoná', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('866', 'Santa Ana', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('867', 'Santa Bárbara', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('868', 'Santa Bárbara', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('869', 'Santa Bárbara (Iscuandé)', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('870', 'Santa Bárbara de Pinto', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('871', 'Santa Catalina', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('872', 'Santa Fé de Antioquia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('873', 'Santa Genoveva de Docorodó', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('874', 'Santa Helena del Opón', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('875', 'Santa Isabel', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('876', 'Santa Lucía', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('877', 'Santa Marta', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('878', 'Santa María', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('879', 'Santa María', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('880', 'Santa Rosa', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('881', 'Santa Rosa', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('882', 'Santa Rosa de Cabal', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('883', 'Santa Rosa de Osos', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('884', 'Santa Rosa de Viterbo', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('885', 'Santa Rosa del Sur', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('886', 'Santa Rosalía', '1', '99');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('887', 'Santa Sofía', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('888', 'Santana', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('889', 'Santander de Quilichao', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('890', 'Santiago', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('891', 'Santiago', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('892', 'Santo Domingo', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('893', 'Santo Tomás', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('894', 'Santuario', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('895', 'Santuario', '1', '66');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('896', 'Sapuyes', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('897', 'Saravena', '1', '81');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('898', 'Sardinata', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('899', 'Sasaima', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('900', 'Sativanorte', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('901', 'Sativasur', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('902', 'Segovia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('903', 'Sesquilé', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('904', 'Sevilla', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('905', 'Siachoque', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('906', 'Sibaté', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('907', 'Sibundoy', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('908', 'Silos', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('909', 'Silvania', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('910', 'Silvia', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('911', 'Simacota', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('912', 'Simijaca', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('913', 'Simití', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('914', 'Sincelejo', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('915', 'Sincé', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('916', 'Sipí', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('917', 'Sitionuevo', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('918', 'Soacha', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('919', 'Soatá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('920', 'Socha', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('921', 'Socorro', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('922', 'Socotá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('923', 'Sogamoso', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('924', 'Solano', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('925', 'Soledad', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('926', 'Solita', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('927', 'Somondoco', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('928', 'Sonsón', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('929', 'Sopetrán', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('930', 'Soplaviento', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('931', 'Sopó', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('932', 'Sora', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('933', 'Soracá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('934', 'Sotaquirá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('935', 'Sotara (Paispamba)', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('936', 'Sotomayor (Los Andes)', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('937', 'Suaita', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('938', 'Suan', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('939', 'Suaza', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('940', 'Subachoque', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('941', 'Sucre', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('942', 'Sucre', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('943', 'Sucre', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('944', 'Suesca', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('945', 'Supatá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('946', 'Supía', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('947', 'Suratá', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('948', 'Susa', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('949', 'Susacón', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('950', 'Sutamarchán', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('951', 'Sutatausa', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('952', 'Sutatenza', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('953', 'Suárez', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('954', 'Suárez', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('955', 'Sácama', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('956', 'Sáchica', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('957', 'Tabio', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('958', 'Tadó', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('959', 'Talaigua Nuevo', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('960', 'Tamalameque', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('961', 'Tame', '1', '81');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('962', 'Taminango', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('963', 'Tangua', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('964', 'Taraira', '1', '97');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('965', 'Tarazá', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('966', 'Tarqui', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('967', 'Tarso', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('968', 'Tasco', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('969', 'Tauramena', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('970', 'Tausa', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('971', 'Tello', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('972', 'Tena', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('973', 'Tenerife', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('974', 'Tenjo', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('975', 'Tenza', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('976', 'Teorama', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('977', 'Teruel', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('978', 'Tesalia', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('979', 'Tibacuy', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('980', 'Tibaná', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('981', 'Tibasosa', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('982', 'Tibirita', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('983', 'Tibú', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('984', 'Tierralta', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('985', 'Timaná', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('986', 'Timbiquí', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('987', 'Timbío', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('988', 'Tinjacá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('989', 'Tipacoque', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('990', 'Tiquisio (Puerto Rico)', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('991', 'Titiribí', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('992', 'Toca', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('993', 'Tocaima', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('994', 'Tocancipá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('995', 'Toguí', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('996', 'Toledo', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('997', 'Toledo', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('998', 'Tolú', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('999', 'Tolú Viejo', '1', '70');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1000', 'Tona', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1001', 'Topagá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1002', 'Topaipí', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1003', 'Toribío', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1004', 'Toro', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1005', 'Tota', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1006', 'Totoró', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1007', 'Trinidad', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1008', 'Trujillo', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1009', 'Tubará', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1010', 'Tuchín', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1011', 'Tulúa', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1012', 'Tumaco', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1013', 'Tunja', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1014', 'Tunungua', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1015', 'Turbaco', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1016', 'Turbaná', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1017', 'Turbo', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1018', 'Turmequé', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1019', 'Tuta', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1020', 'Tutasá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1021', 'Támara', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1022', 'Támesis', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1023', 'Túquerres', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1024', 'Ubalá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1025', 'Ubaque', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1026', 'Ubaté', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1027', 'Ulloa', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1028', 'Une', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1029', 'Unguía', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1030', 'Unión Panamericana (ÁNIMAS)', '1', '27');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1031', 'Uramita', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1032', 'Uribe', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1033', 'Uribia', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1034', 'Urrao', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1035', 'Urumita', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1036', 'Usiacuri', '1', '8');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1037', 'Valdivia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1038', 'Valencia', '1', '23');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1039', 'Valle de San José', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1040', 'Valle de San Juan', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1041', 'Valle del Guamuez', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1042', 'Valledupar', '1', '20');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1043', 'Valparaiso', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1044', 'Valparaiso', '1', '18');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1045', 'Vegachí', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1046', 'Venadillo', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1047', 'Venecia', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1048', 'Venecia (Ospina Pérez)', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1049', 'Ventaquemada', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1050', 'Vergara', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1051', 'Versalles', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1052', 'Vetas', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1053', 'Viani', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1054', 'Vigía del Fuerte', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1055', 'Vijes', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1056', 'Villa Caro', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1057', 'Villa Rica', '1', '19');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1058', 'Villa de Leiva', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1059', 'Villa del Rosario', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1060', 'Villagarzón', '1', '86');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1061', 'Villagómez', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1062', 'Villahermosa', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1063', 'Villamaría', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1064', 'Villanueva', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1065', 'Villanueva', '1', '44');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1066', 'Villanueva', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1067', 'Villanueva', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1068', 'Villapinzón', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1069', 'Villarrica', '1', '73');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1070', 'Villavicencio', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1071', 'Villavieja', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1072', 'Villeta', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1073', 'Viotá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1074', 'Viracachá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1075', 'Vista Hermosa', '1', '50');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1076', 'Viterbo', '1', '17');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1077', 'Vélez', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1078', 'Yacopí', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1079', 'Yacuanquer', '1', '52');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1080', 'Yaguará', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1081', 'Yalí', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1082', 'Yarumal', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1083', 'Yolombó', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1084', 'Yondó (Casabe)', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1085', 'Yopal', '1', '85');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1086', 'Yotoco', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1087', 'Yumbo', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1088', 'Zambrano', '1', '13');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1089', 'Zapatoca', '1', '68');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1090', 'Zapayán (PUNTA DE PIEDRAS)', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1091', 'Zaragoza', '1', '5');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1092', 'Zarzal', '1', '76');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1093', 'Zetaquirá', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1094', 'Zipacón', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1095', 'Zipaquirá', '1', '25');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1096', 'Zona Bananera (PRADO - SEVILLA)', '1', '47');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1097', 'Ábrego', '1', '54');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1098', 'Íquira', '1', '41');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1099', 'Úmbita', '1', '15');
INSERT INTO `municipios` (`id_municipio`, `municipio`, `estado`, `departamento_id`) VALUES ('1100', 'Útica', '1', '25');


#
# TABLE STRUCTURE FOR: nivel_escolaridad
#

DROP TABLE IF EXISTS `nivel_escolaridad`;

CREATE TABLE `nivel_escolaridad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nivel` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `nivel_escolaridad` (`id`, `nivel`) VALUES ('1', 'Ninguno');
INSERT INTO `nivel_escolaridad` (`id`, `nivel`) VALUES ('2', 'Primaria');
INSERT INTO `nivel_escolaridad` (`id`, `nivel`) VALUES ('3', 'Secundaria');
INSERT INTO `nivel_escolaridad` (`id`, `nivel`) VALUES ('4', 'Técnico');
INSERT INTO `nivel_escolaridad` (`id`, `nivel`) VALUES ('5', 'tecnologo');
INSERT INTO `nivel_escolaridad` (`id`, `nivel`) VALUES ('6', 'Universitario');
INSERT INTO `nivel_escolaridad` (`id`, `nivel`) VALUES ('7', 'Postgrado');


#
# TABLE STRUCTURE FOR: referencias_personal
#

DROP TABLE IF EXISTS `referencias_personal`;

CREATE TABLE `referencias_personal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(200) NOT NULL,
  `parentesco` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `celular` varchar(20) NOT NULL,
  `persona_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

INSERT INTO `referencias_personal` (`id`, `nombres`, `parentesco`, `telefono`, `celular`, `persona_id`) VALUES ('28', 'juan martinez', 'amigo', '454545', '980911211', '7');
INSERT INTO `referencias_personal` (`id`, `nombres`, `parentesco`, `telefono`, `celular`, `persona_id`) VALUES ('29', 'Miguel cervanrtez', 'padrasto', '454645', '980911212', '7');
INSERT INTO `referencias_personal` (`id`, `nombres`, `parentesco`, `telefono`, `celular`, `persona_id`) VALUES ('30', 'Juan Quispe', 'amigo', '565654', '98998122', '7');
INSERT INTO `referencias_personal` (`id`, `nombres`, `parentesco`, `telefono`, `celular`, `persona_id`) VALUES ('31', 'Claudio Salinas', 'Padre', '05444231', '988111001', '7');
INSERT INTO `referencias_personal` (`id`, `nombres`, `parentesco`, `telefono`, `celular`, `persona_id`) VALUES ('32', 'yony', 'amigo', '05444231', '988111001', '7');
INSERT INTO `referencias_personal` (`id`, `nombres`, `parentesco`, `telefono`, `celular`, `persona_id`) VALUES ('33', '', '', '', '', '7');
INSERT INTO `referencias_personal` (`id`, `nombres`, `parentesco`, `telefono`, `celular`, `persona_id`) VALUES ('34', 'eugenia flores', 'Madre', '05444231', '988111001', '8');
INSERT INTO `referencias_personal` (`id`, `nombres`, `parentesco`, `telefono`, `celular`, `persona_id`) VALUES ('35', 'Maria Caceres', 'Amiga', '05444231', '988111001', '8');
INSERT INTO `referencias_personal` (`id`, `nombres`, `parentesco`, `telefono`, `celular`, `persona_id`) VALUES ('36', 'Emanuel gonzales', 'Amigo', '05444231', '988111001', '8');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `roles` (`id`, `nombre`) VALUES ('1', 'Administrador');
INSERT INTO `roles` (`id`, `nombre`) VALUES ('2', 'Usuario');
INSERT INTO `roles` (`id`, `nombre`) VALUES ('3', 'Gestor de Archivos');


#
# TABLE STRUCTURE FOR: tipo_identificacion
#

DROP TABLE IF EXISTS `tipo_identificacion`;

CREATE TABLE `tipo_identificacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipoidentificacion` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `tipo_identificacion` (`id`, `tipoidentificacion`) VALUES ('1', 'C.E.');
INSERT INTO `tipo_identificacion` (`id`, `tipoidentificacion`) VALUES ('2', 'C.C.');
INSERT INTO `tipo_identificacion` (`id`, `tipoidentificacion`) VALUES ('3', 'Pasaporte');
INSERT INTO `tipo_identificacion` (`id`, `tipoidentificacion`) VALUES ('4', 'Otro');


#
# TABLE STRUCTURE FOR: usuarios
#

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) NOT NULL,
  `nombres` varchar(200) NOT NULL,
  `apellidos` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `rol_id` int(11) NOT NULL,
  `estado` tinyint(1) NOT NULL,
  `password` varchar(100) NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `imagen` text NOT NULL,
  `hoja` text NOT NULL,
  `firma` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `usuarios` (`id`, `cedula`, `nombres`, `apellidos`, `email`, `rol_id`, `estado`, `password`, `sexo`, `imagen`, `hoja`, `firma`) VALUES ('1', '1074185973', 'LEYDY XIMENA', '', 'administracion.riesgos@fesun.com.co', '1', '1', '25a77eed770bad35a326b32722d9db0249203a5f', 'F', 'imagen_femenino.jpg', '', '');
INSERT INTO `usuarios` (`id`, `cedula`, `nombres`, `apellidos`, `email`, `rol_id`, `estado`, `password`, `sexo`, `imagen`, `hoja`, `firma`) VALUES ('6', '98384', 'Silvio ', 'Lopez', 'pitsolus@gmail.com', '1', '1', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '', '', '', '');


#
# TABLE STRUCTURE FOR: usuarios_fincas
#

DROP TABLE IF EXISTS `usuarios_fincas`;

CREATE TABLE `usuarios_fincas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `finca_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('1', '1', '1');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('7', '1', '2');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('8', '1', '3');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('9', '1', '4');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('10', '1', '5');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('11', '1', '6');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('12', '1', '7');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('13', '1', '8');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('14', '1', '9');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('15', '1', '10');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('16', '1', '11');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('17', '1', '12');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('18', '1', '13');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('19', '1', '14');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('20', '1', '15');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('21', '1', '16');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('22', '1', '17');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('23', '1', '18');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('24', '1', '19');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('25', '1', '20');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('26', '1', '21');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('27', '1', '22');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('28', '1', '23');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('29', '1', '24');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('30', '1', '25');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('31', '1', '26');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('33', '1', '27');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('34', '1', '28');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('35', '1', '29');
INSERT INTO `usuarios_fincas` (`id`, `usuario_id`, `finca_id`) VALUES ('36', '1', '30');


#
# TABLE STRUCTURE FOR: vinculaciones
#

DROP TABLE IF EXISTS `vinculaciones`;

CREATE TABLE `vinculaciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vinculacion` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `vinculaciones` (`id`, `vinculacion`) VALUES ('1', 'Vinculacion');
INSERT INTO `vinculaciones` (`id`, `vinculacion`) VALUES ('2', 'Actualizacion');
INSERT INTO `vinculaciones` (`id`, `vinculacion`) VALUES ('3', 'Vinculacion por Primera vez');
INSERT INTO `vinculaciones` (`id`, `vinculacion`) VALUES ('4', 'Reingreso');


#
# TABLE STRUCTURE FOR: viviendas
#

DROP TABLE IF EXISTS `viviendas`;

CREATE TABLE `viviendas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vivienda` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

INSERT INTO `viviendas` (`id`, `vivienda`) VALUES ('1', 'Propia');
INSERT INTO `viviendas` (`id`, `vivienda`) VALUES ('2', 'Hipotecada');
INSERT INTO `viviendas` (`id`, `vivienda`) VALUES ('3', 'Arrendada');
INSERT INTO `viviendas` (`id`, `vivienda`) VALUES ('4', 'Financiada');
INSERT INTO `viviendas` (`id`, `vivienda`) VALUES ('5', 'Familiar');


